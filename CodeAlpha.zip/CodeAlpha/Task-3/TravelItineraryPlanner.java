import java.util.ArrayList;
import java.util.Scanner;

public class TravelItineraryPlanner {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Destination> itinerary = new ArrayList<>();

        System.out.println("Welcome to the Travel Itinerary Planner!");

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Add Destination");
            System.out.println("2. View Itinerary");
            System.out.println("3. Calculate Budget");
            System.out.println("4. Check Weather Information");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character

            switch (choice) {
                case 1:
                    System.out.print("Enter destination: ");
                    String destination = scanner.nextLine();
                    System.out.print("Enter start date (yyyy-mm-dd): ");
                    String startDate = scanner.nextLine();
                    System.out.print("Enter end date (yyyy-mm-dd): ");
                    String endDate = scanner.nextLine();
                    System.out.print("Enter daily budget: ");
                    double dailyBudget = scanner.nextDouble();
                    scanner.nextLine(); // Consume newline character

                    itinerary.add(new Destination(destination, startDate, endDate, dailyBudget));
                    System.out.println("Destination added successfully!");
                    break;

                case 2:
                    if (itinerary.isEmpty()) {
                        System.out.println("Your itinerary is empty. Add some destinations first.");
                    } else {
                        System.out.println("\nYour Itinerary:");
                        for (int i = 0; i < itinerary.size(); i++) {
                            System.out.println("Destination " + (i + 1) + ":");
                            System.out.println(itinerary.get(i).toFormattedString());
                        }
                    }
                    break;

                case 3:
                    double totalBudget = calculateTotalBudget(itinerary);
                    System.out.printf("Your total budget for the trip is: %.2f%n", totalBudget);
                    break;

                case 4:
                    System.out.println("Weather feature is under development. Stay tuned!");
                    break;

                case 5:
                    System.out.println("Exiting the Travel Itinerary Planner. Have a great trip!");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    // Method to calculate the total budget
    public static double calculateTotalBudget(ArrayList<Destination> itinerary) {
        double totalBudget = 0;
        for (Destination destination : itinerary) {
            totalBudget += destination.getTotalBudget();
        }
        return totalBudget;
    }
}

// Destination class to store details of each destination
class Destination {
    private String destination;
    private String startDate;
    private String endDate;
    private double dailyBudget;

    public Destination(String destination, String startDate, String endDate, double dailyBudget) {
        this.destination = destination;
        this.startDate = startDate;
        this.endDate = endDate;
        this.dailyBudget = dailyBudget;
    }

    // Method to calculate the total budget for this destination
    public double getTotalBudget() {
        int days = calculateDays(startDate, endDate);
        return days * dailyBudget;
    }

    // Method to calculate the number of days between start and end dates
    private int calculateDays(String startDate, String endDate) {
        String[] start = startDate.split("-");
        String[] end = endDate.split("-");

        int startYear = Integer.parseInt(start[0]);
        int startMonth = Integer.parseInt(start[1]);
        int startDay = Integer.parseInt(start[2]);

        int endYear = Integer.parseInt(end[0]);
        int endMonth = Integer.parseInt(end[1]);
        int endDay = Integer.parseInt(end[2]);

        int daysInStartMonth = daysInMonth(startMonth, startYear);
        int days = (endYear - startYear) * 365 + (endMonth - startMonth) * daysInStartMonth + (endDay - startDay);
        return Math.max(days, 1); // Ensure at least 1 day
    }

    // Helper method to get the number of days in a month
    private int daysInMonth(int month, int year) {
        switch (month) {
            case 4: case 6: case 9: case 11:
                return 30;
            case 2:
                return (isLeapYear(year)) ? 29 : 28;
            default:
                return 31;
        }
    }

    // Helper method to check if a year is a leap year
    private boolean isLeapYear(int year) {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
    }

    // Method to format the output of a destination
    public String toFormattedString() {
        return "Destination: " + destination + "\n" +
               "Start Date: " + startDate + "\n" +
               "End Date: " + endDate + "\n" +
               "Daily Budget: " + dailyBudget + "\n" +
               "Total Budget: " + getTotalBudget();
    }

    @Override
    public String toString() {
        return "Destination: " + destination + ", Dates: " + startDate + " to " + endDate +
                ", Daily Budget: " + dailyBudget;
    }
}
