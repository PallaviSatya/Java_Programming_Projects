import java.util.ArrayList;
import java.util.Scanner;

// Room class
class Room {
    int roomNumber;
    String roomType; // Single, Double, Suite
    double pricePerNight;
    boolean isAvailable;

    Room(int roomNumber, String roomType, double pricePerNight) {
        this.roomNumber = roomNumber;
        this.roomType = roomType;
        this.pricePerNight = pricePerNight;
        this.isAvailable = true;
    }

    void displayRoomInfo() {
        System.out.printf("Room Number: %d, Type: %s, Price: ₹%.2f, Available: %s%n",
                roomNumber, roomType, pricePerNight, isAvailable ? "Yes" : "No");
    }
}

// Booking class
class Booking {
    String customerName;
    int roomNumber;
    int numberOfNights;
    double totalCost;

    Booking(String customerName, int roomNumber, int numberOfNights, double totalCost) {
        this.customerName = customerName;
        this.roomNumber = roomNumber;
        this.numberOfNights = numberOfNights;
        this.totalCost = totalCost;
    }

    void displayBookingDetails() {
        System.out.println("Name: " + customerName);
        System.out.println("Room Number: " + roomNumber);
        System.out.println("Nights: " + numberOfNights);
        System.out.printf("Total Cost: ₹%.2f%n", totalCost);
        System.out.println("-------------------------");
    }
}

// Main HotelReservationSystem class
public class HotelReservationSystem {
    static ArrayList<Room> rooms = new ArrayList<>();
    static ArrayList<Booking> bookings = new ArrayList<>();
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        initializeRooms();

        System.out.println("Welcome to the Hotel Reservation System!");

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. View Available Rooms");
            System.out.println("2. Make a Reservation");
            System.out.println("3. View Booking Details");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    viewAvailableRooms();
                    break;
                case 2:
                    makeReservation();
                    break;
                case 3:
                    viewBookingDetails();
                    break;
                case 4:
                    System.out.println("Thank you for using the Hotel Reservation System. Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    // Initialize rooms with sample data
    static void initializeRooms() {
        rooms.add(new Room(101, "Single", 2000));
        rooms.add(new Room(102, "Single", 2000));
        rooms.add(new Room(201, "Double", 3500));
        rooms.add(new Room(202, "Double", 3500));
        rooms.add(new Room(301, "Suite", 5000));
    }

    // Display available rooms
    static void viewAvailableRooms() {
        System.out.println("\nAvailable Rooms:");
        boolean found = false;
        for (Room room : rooms) {
            if (room.isAvailable) {
                room.displayRoomInfo();
                found = true;
            }
        }
        if (!found) {
            System.out.println("No rooms available.");
        }
    }

    // Make a reservation
    static void makeReservation() {
        System.out.println("\nEnter your name:");
        String customerName = scanner.nextLine();

        System.out.println("Enter the room number you want to book:");
        int roomNumber = scanner.nextInt();

        Room selectedRoom = null;
        for (Room room : rooms) {
            if (room.roomNumber == roomNumber && room.isAvailable) {
                selectedRoom = room;
                break;
            }
        }

        if (selectedRoom == null) {
            System.out.println("Room not available or does not exist.");
            return;
        }

        System.out.println("Enter the number of nights:");
        int numberOfNights = scanner.nextInt();

        double totalCost = selectedRoom.pricePerNight * numberOfNights;

        // Simulate payment
        System.out.printf("Total cost: ₹%.2f. Enter '1' to confirm payment: ", totalCost);
        int paymentConfirmation = scanner.nextInt();

        if (paymentConfirmation == 1) {
            // Mark room as booked
            selectedRoom.isAvailable = false;

            // Add booking details
            bookings.add(new Booking(customerName, roomNumber, numberOfNights, totalCost));
            System.out.println("Reservation successful!");
        } else {
            System.out.println("Payment not confirmed. Reservation canceled.");
        }
    }

    // View booking details
    static void viewBookingDetails() {
        System.out.println("\nBooking Details:");
        if (bookings.isEmpty()) {
            System.out.println("No bookings found.");
        } else {
            for (Booking booking : bookings) {
                booking.displayBookingDetails();
            }
        }
    }
}
